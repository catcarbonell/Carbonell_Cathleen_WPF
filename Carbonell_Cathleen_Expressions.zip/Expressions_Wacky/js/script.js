// Cathleen Carbonell | 7/17/204 | Expressions Wacky

//How many plush pigs can fit in a room?

//First let's get the inch measurements of the plush pigs

var pig1 = prompt("What's the size of pig 1 in inches?");
var pig2 = prompt("What is the size of pig 2?");
var pig3 = prompt("Finally, pig 3?");

//We need to find the sq ft measurement of the pigs, so since there are 12 inches to 1 sq ft, we divide the number by 12
var piggies = [pig1, pig2, pig3];

var sqftpig1 = piggies[0] /12;
var sqftpig2 = piggies[1] /12;
var sqftpig3 = piggies[2] /12;


// We need the sum of all 3 plush pigs in sq ft
var sumpiggies = sqftpig1 + sqftpig2 + sqftpig3;

// We need the size of the room in sq ft
var width = prompt("What is the width of the room in sq ft?");
var height= prompt("What is the height of the room in sq ft?");

var room = width * height;

// The equation for the problem:
var totalsqftpigs = sumpiggies / room;

//Here is the printed result:
console.log("Only " + totalsqftpigs + " pig(gies)fit in a " + width + "x" + height + " sq ft room.");
